Change log
===
- 2.2.1: Documentation fixes and added proj4.defs('name') as an alias for proj4.defs['name'];

- 2.1.4: dist folder is added back in after accidentally omitting it in 2.1.1

- 2.1.3: skipped as issues with the dist folder are ironed out.

- 2.1.2: added sensible defaults for false eastings/northings

- 2.1.1: tweaks to how we publish it, fixes related to errors with the OSGB36 and Reseau National Belge 1972 datums, we took the first steps towards depreciating the proj4.Point class.

- 2.1.0: targeted builds for projections are now supported, and internally projection creation is more modular.

- 2.0.3: mgrs is broken out into it's own module loaded via npm.

- 2.0.2: module common is broken up into a collection of smaller modules. 

- 2.0.1: fix typo in eqc projection.

- 2.0.0: we start the change log.